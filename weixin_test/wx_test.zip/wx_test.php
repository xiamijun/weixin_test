<?php
/**
  * 关键词自动回复和被关注自动回复
  */

//define your token
define("TOKEN", "weixin");
$wechatObj = new wechatCallbackapiTest();
$wechatObj->responseMsg();

class wechatCallbackapiTest
{

    public function responseMsg()
    {
		//get post data, May be due to the different environments
		$postStr = $GLOBALS["HTTP_RAW_POST_DATA"];

      	//extract post data
		if (!empty($postStr)){
			/* libxml_disable_entity_loader is to prevent XML eXternal Entity Injection,
			   the best way is to check the validity of xml by yourself */
			libxml_disable_entity_loader(true);
			$postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);
			$fromUsername = $postObj->FromUserName;
			$toUsername = $postObj->ToUserName;
			$msgType=$postObj->Msgtype;
			$event=$postObj->Event;
			$keyword = trim($postObj->Content);
			$time = time();
			$textTpl = "<xml>
						<ToUserName><![CDATA[%s]]></ToUserName>
						<FromUserName><![CDATA[%s]]></FromUserName>
						<CreateTime>%s</CreateTime>
						<MsgType><![CDATA[%s]]></MsgType>
						<Content><![CDATA[%s]]></Content>
						<FuncFlag>0</FuncFlag>
						</xml>";
			switch($msgType){
				case 'event':
					if($event=='subscribe'){
						$contentStr='感谢你的关注，回复1，2，3';
					}
				break;
				case 'text':
					switch($keyword){
						case '1':
							$contentStr="关键词为1";
							break;
						case '2':
							$contentStr='关键词为2';
							break;
						case '3':
							$contentStr='关键词为2';
							break;
						default:
							$contentStr='对不起，你的消息我会稍后回复';
					}
					break;
			}
			$msgType='text';
				$resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
				echo $resultStr;


        }else {
        	echo "";
        	exit;
        }
    }

}

?>